<?php

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.html");
    exit;
}

$name    = trim($_POST['name'] ?? '');
$email   = trim($_POST['email'] ?? '');
$subject = trim($_POST['subject'] ?? '');
$message = trim($_POST['message'] ?? '');

if (empty($name) || empty($email) || empty($subject) || empty($message)) {
    die("Please fill in all required fields.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Please enter a valid email address.");
}

$name    = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
$email   = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
$subject = htmlspecialchars($subject, ENT_QUOTES, 'UTF-8');
$message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

$to = "mohit.gupta200897@gmail.com";

$email_subject = "New Portfolio Contact: " . $subject;

$email_body = "
<html>
<head>
    <title>New Portfolio Contact</title>
</head>
<body>
    <h2>New Contact Form Submission</h2>

    <p><strong>Name:</strong> {$name}</p>
    <p><strong>Email:</strong> {$email}</p>
    <p><strong>Subject:</strong> {$subject}</p>

    <p><strong>Message:</strong></p>
    <p>" . nl2br($message) . "</p>

</body>
</html>
";

$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
$headers .= "From: Portfolio Website <noreply@" . $_SERVER['HTTP_HOST'] . ">\r\n";
$headers .= "Reply-To: {$email}\r\n";

if (mail($to, $email_subject, $email_body, $headers)) {

    echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Thank You | Mohit Gupta</title>

        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                font-family: Arial, sans-serif;
                background: #111;
                color: #fff;
            }

            .thankyou-box {
                width: 100%;
                max-width: 650px;
                padding: 55px 35px;
                text-align: center;
                border-radius: 15px;
                background: #1a1a1a;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.45);
                border: 1px solid rgba(255, 255, 255, 0.08);
            }

            .check {
                width: 80px;
                height: 80px;
                margin: 0 auto 25px;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                background: #00c896;
                color: #fff;
                font-size: 42px;
                font-weight: bold;
            }

            h1 {
                font-size: 38px;
                margin-bottom: 18px;
            }

            p {
                color: #bdbdbd;
                font-size: 16px;
                line-height: 1.8;
                margin-bottom: 30px;
            }

            .back-btn {
                display: inline-block;
                padding: 13px 28px;
                border-radius: 30px;
                background: #00c896;
                color: #fff;
                text-decoration: none;
                font-size: 14px;
                font-weight: 600;
                transition: 0.3s ease;
            }

            .back-btn:hover {
                background: #fff;
                color: #111;
            }

            @media (max-width: 576px) {
                .thankyou-box {
                    padding: 40px 22px;
                }

                h1 {
                    font-size: 30px;
                }

                p {
                    font-size: 15px;
                }
            }
        </style>
    </head>

    <body>

        <div class="thankyou-box">

            <div class="check">✓</div>

            <h1>Thank You!</h1>

            <p>
                Your message has been successfully sent.
                I really appreciate you taking the time to get in touch.
                I will review your message and get back to you as soon as possible.
            </p>

            <a href="index.html" class="back-btn">
                Back to Portfolio
            </a>

        </div>

    </body>
    </html>
    ';

} else {

    echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Message Not Sent</title>
    </head>

    <body style="
        margin:0;
        min-height:100vh;
        display:flex;
        align-items:center;
        justify-content:center;
        background:#111;
        color:#fff;
        font-family:Arial,sans-serif;
        text-align:center;
        padding:20px;
    ">

        <div>
            <h1>Something went wrong.</h1>

            <p style="color:#bbb;">
                Your message could not be sent right now.
                Please try again later.
            </p>

            <a href="index.html"
               style="
               display:inline-block;
               padding:12px 25px;
               background:#00c896;
               color:#fff;
               text-decoration:none;
               border-radius:30px;
               ">
               Back to Portfolio
            </a>
        </div>

    </body>
    </html>
    ';
}
?>